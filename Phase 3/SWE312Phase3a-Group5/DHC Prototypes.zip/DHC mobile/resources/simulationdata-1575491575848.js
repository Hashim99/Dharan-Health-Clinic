function initData() {
  jimData.variables["Mail"] = "";
  jimData.variables["slide"] = "";
  jimData.isInitialized = true;
}