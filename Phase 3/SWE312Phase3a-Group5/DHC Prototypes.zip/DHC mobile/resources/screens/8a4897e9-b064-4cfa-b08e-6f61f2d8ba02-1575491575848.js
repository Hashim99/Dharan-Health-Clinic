jQuery("#simulation")
  .on("pageload", ".s-8a4897e9-b064-4cfa-b08e-6f61f2d8ba02 .pageload", function(event, data) {
    var jEvent, jFirer, cases;
    if(data === undefined) { data = event; }
    jEvent = jimEvent(event);
    jFirer = jEvent.getEventFirer();
    if(jFirer.is("#s-8a4897e9-b064-4cfa-b08e-6f61f2d8ba02")) {
      cases = [
        {
          "blocks": [
            {
              "actions": [
                {
                  "action": "jimNavigation",
                  "parameter": {
                    "target": "screens/2575f860-ae98-4540-8c52-1507c92e0de1",
                    "transition": {
                      "type": "fade",
                      "duration": 3000
                    }
                  },
                  "exectype": "serial",
                  "delay": 0
                }
              ]
            }
          ],
          "exectype": "serial",
          "delay": 0
        }
      ];
      event.data = data;
      jEvent.launchCases(cases);
    }
  });