function initData() {
  jimData.variables["value"] = "";
  jimData.isInitialized = true;
}