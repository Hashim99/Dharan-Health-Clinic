(function(window, undefined) {

  var jimLinks = {
    "079d292a-18e4-4139-8bad-52e27cc52347" : {
      "Button1" : [
        "05a5cd56-bf70-4927-ad6b-1504b51179d9"
      ],
      "Rectangle_4" : [
        "05a5cd56-bf70-4927-ad6b-1504b51179d9"
      ],
      "Rectangle_5" : [
        "05a5cd56-bf70-4927-ad6b-1504b51179d9"
      ],
      "Rectangle_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "5fdfe5cc-0c3b-4d60-9609-e159d6774f30" : {
      "Button1" : [
        "20467c68-1ab2-4dd1-9000-b053b58545d3"
      ],
      "Button1_1" : [
        "4ef6cbfa-fae2-4a11-bb8d-29e1e12b3744"
      ],
      "Hotspot_1" : [
        "30aad493-b067-40ce-ae8a-434b7b547013"
      ],
      "Rectangle_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "30aad493-b067-40ce-ae8a-434b7b547013" : {
      "Rectangle_4" : [
        "4ef6cbfa-fae2-4a11-bb8d-29e1e12b3744"
      ],
      "Rectangle_5" : [
        "4ef6cbfa-fae2-4a11-bb8d-29e1e12b3744"
      ],
      "Rectangle_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "a9b34a1d-190c-4843-9e9d-67550a1ea8ae" : {
      "Button1" : [
        "246ac1db-ac43-4fbc-bc32-90bc5186f07f"
      ],
      "Rectangle_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "05a5cd56-bf70-4927-ad6b-1504b51179d9" : {
      "Button2" : [
        "079d292a-18e4-4139-8bad-52e27cc52347"
      ],
      "Rectangle_9" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "4ef6cbfa-fae2-4a11-bb8d-29e1e12b3744" : {
      "Button1" : [
        "5fdfe5cc-0c3b-4d60-9609-e159d6774f30"
      ],
      "Button2" : [
        "20467c68-1ab2-4dd1-9000-b053b58545d3"
      ],
      "Hotspot_1" : [
        "30aad493-b067-40ce-ae8a-434b7b547013"
      ],
      "Rectangle_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "246ac1db-ac43-4fbc-bc32-90bc5186f07f" : {
      "Rectangle_10" : [
        "a9b34a1d-190c-4843-9e9d-67550a1ea8ae"
      ],
      "Hotspot_1" : [
        "a9b34a1d-190c-4843-9e9d-67550a1ea8ae"
      ],
      "Rectangle_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "cfce8950-23fb-4bc4-8917-95d4c3cbb6c5" : {
      "Button2" : [
        "079d292a-18e4-4139-8bad-52e27cc52347"
      ],
      "Rectangle_28" : [
        "05a5cd56-bf70-4927-ad6b-1504b51179d9"
      ],
      "Hotspot_3" : [
        "05a5cd56-bf70-4927-ad6b-1504b51179d9"
      ],
      "Rectangle_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "20467c68-1ab2-4dd1-9000-b053b58545d3" : {
      "Button1" : [
        "5fdfe5cc-0c3b-4d60-9609-e159d6774f30"
      ],
      "Button1_1" : [
        "4ef6cbfa-fae2-4a11-bb8d-29e1e12b3744"
      ],
      "Hotspot_1" : [
        "30aad493-b067-40ce-ae8a-434b7b547013"
      ],
      "Rectangle_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Rectangle_4" : [
        "05a5cd56-bf70-4927-ad6b-1504b51179d9",
        "a9b34a1d-190c-4843-9e9d-67550a1ea8ae",
        "30aad493-b067-40ce-ae8a-434b7b547013"
      ]
    },
    "82f95b41-e209-4c70-bf12-cb4c3e59e70a" : {
      "Button2" : [
        "079d292a-18e4-4139-8bad-52e27cc52347"
      ],
      "Rectangle_27" : [
        "05a5cd56-bf70-4927-ad6b-1504b51179d9"
      ],
      "Rectangle_28" : [
        "05a5cd56-bf70-4927-ad6b-1504b51179d9"
      ],
      "Hotspot_3" : [
        "05a5cd56-bf70-4927-ad6b-1504b51179d9"
      ],
      "Rectangle_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);